from flask import Flask, request, jsonify
from flask_cors import CORS
from utils import load_db, save_db
import re

app = Flask(__name__)
CORS(app)

SAFE_FOOD_DB = {
    "general": ["fruits", "vegetables", "whole grains", "water", "green tea"],
    "diabetes": ["oats", "leafy greens", "lentils", "nuts"],
    "hypertension": ["banana", "beetroot", "low-fat yogurt", "garlic"],
    "anemia": ["spinach", "beans", "dates", "lean meat"]
}

def parse_medical_record(text):
    conditions = []
    if re.search(r"diabetes", text, re.I): conditions.append("diabetes")
    if re.search(r"hypertension|high bp|blood pressure", text, re.I): conditions.append("hypertension")
    if re.search(r"anemia|low iron", text, re.I): conditions.append("anemia")
    return conditions

def compute_item_effects(user_id):
    db = load_db()
    logs = [l for l in db["logs"] if l["user_id"] == user_id]
    stats = {}
    for l in logs:
        for f in l["foods"]:
            if f not in stats:
                stats[f] = []
            stats[f].append(l["alertness"])
    return {"items": [{"item":k, "delta": (sum(v)/len(v))-5} for k,v in stats.items()]}

def recommend_foods(user_id):
    db = load_db()
    analysis = compute_item_effects(user_id)
    risky = [i["item"] for i in analysis["items"] if i["delta"] < -0.5]

    medical_text = db.get("medical_records",{}).get(user_id,"")
    conditions = parse_medical_record(medical_text)

    safe_foods = SAFE_FOOD_DB["general"]
    for c in conditions:
        safe_foods += SAFE_FOOD_DB.get(c,[])
    safe_foods = [f for f in safe_foods if f not in risky]

    return {"risky_foods": risky, "conditions": conditions, "recommended_safe_foods": list(set(safe_foods))}

@app.route("/api/log", methods=["POST"])
def log_food():
    data = request.json
    db = load_db()
    db["logs"].append(data)
    save_db(db)
    return jsonify({"status":"ok"})

@app.route("/api/upload_medical", methods=["POST"])
def upload_medical():
    user_id = request.form.get("user_id")
    file = request.files["file"]
    text = file.read().decode("utf-8", errors="ignore")
    db = load_db()
    db["medical_records"][user_id] = text
    save_db(db)
    return jsonify({"status":"uploaded","conditions":parse_medical_record(text)})

@app.route("/api/recommend", methods=["GET"])
def api_recommend():
    user_id = request.args.get("user_id")
    return jsonify(recommend_foods(user_id))

if __name__ == "__main__":
    app.run(debug=True, port=5000)
