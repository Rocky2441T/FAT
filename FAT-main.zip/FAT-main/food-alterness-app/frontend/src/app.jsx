import React from "react";
import FoodLogForm from "./components/FoodLogForm";
import MedicalUpload from "./components/MedicalUpload";
import RecommendationView from "./components/RecommendationView";
import NavBar from "./components/NavBar";

export default function App() {
  return (
    <div>
      <NavBar />
      <h1>🍎 Food & Alertness Tracker</h1>
      <FoodLogForm />
      <MedicalUpload />
      <RecommendationView />
    </div>
  );
}
