import React, { useState } from "react";
import axios from "axios";

export default function RecommendationView() {
  const [rec, setRec] = useState(null);

  const getRec = async () => {
    const res = await axios.get("http://127.0.0.1:5000/api/recommend?user_id=user1");
    setRec(res.data);
  };

  return (
    <div>
      <h3>Recommendations</h3>
      <button onClick={getRec}>Get My Diet Suggestions</button>
      {rec && (
        <div>
          <p><b>Conditions:</b> {rec.conditions.join(", ")}</p>
          <p><b>Risky Foods:</b> {rec.risky_foods.join(", ")}</p>
          <p><b>Safe Foods:</b> {rec.recommended_safe_foods.join(", ")}</p>
        </div>
      )}
    </div>
  );
}
