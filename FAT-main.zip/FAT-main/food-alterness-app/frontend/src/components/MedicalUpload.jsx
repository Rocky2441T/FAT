import React, { useState } from "react";
import axios from "axios";

export default function MedicalUpload() {
  const [file, setFile] = useState(null);

  const upload = async () => {
    const formData = new FormData();
    formData.append("user_id", "user1");
    formData.append("file", file);
    const res = await axios.post("http://127.0.0.1:5000/api/upload_medical", formData);
    alert("Uploaded! Conditions: " + res.data.conditions.join(", "));
  };

  return (
    <div>
      <h3>Upload Medical Record</h3>
      <input type="file" onChange={e => setFile(e.target.files[0])} />
      <button onClick={upload}>Upload</button>
    </div>
  );
}
