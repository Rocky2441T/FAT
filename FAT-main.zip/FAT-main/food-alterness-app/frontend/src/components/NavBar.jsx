export default function NavBar() {
  return (
    <nav style={{ background: "#333", color: "white", padding: "10px" }}>
      <span>Food-Health App</span>
    </nav>
  );
}
