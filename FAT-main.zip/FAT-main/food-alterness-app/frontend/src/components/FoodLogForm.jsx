import React, { useState } from "react";
import axios from "axios";

export default function FoodLogForm() {
  const [foods, setFoods] = useState("");
  const [alertness, setAlertness] = useState(5);

  const submitLog = async () => {
    await axios.post("http://127.0.0.1:5000/api/log", {
      user_id: "user1",
      foods: foods.split(","),
      alertness: parseInt(alertness)
    });
    alert("Log saved!");
  };

  return (
    <div>
      <h3>Log Your Food</h3>
      <input placeholder="food1,food2" onChange={e => setFoods(e.target.value)} />
      <input type="number" min="1" max="10" value={alertness} onChange={e => setAlertness(e.target.value)} />
      <button onClick={submitLog}>Save</button>
    </div>
  );
}
